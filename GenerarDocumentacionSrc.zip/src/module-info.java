module IPS {
	requires java.sql;
}