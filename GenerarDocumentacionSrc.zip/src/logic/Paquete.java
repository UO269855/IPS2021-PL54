package logic;

import java.util.ArrayList;
import java.util.List;



public class Paquete {
   private List<Producto> listaProductos;
   
   public Paquete() {
	   this.listaProductos = new ArrayList<Producto>();
   }

public List<Producto> getListaProductos() {
	return listaProductos;
}
}

