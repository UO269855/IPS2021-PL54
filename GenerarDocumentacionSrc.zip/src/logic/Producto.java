package logic;

import java.util.UUID;

public class Producto {
private String idProducto;
private String nombre;
private double precio;
private String descripcion;
private int unidades;

public Producto( String nombre, double precio, String descripcion, int unidades) {
	super();
	this.idProducto = UUID.randomUUID().toString();; //el id del producto deberia generarse aleatoriamente 
	this.nombre = nombre;
	this.precio = precio;
	this.descripcion = descripcion;
	this.unidades = unidades;
}

public String getIdProducto() {
	return idProducto;
}

public String getNombre() {
	return nombre;
}

public double getPrecio() {
	return precio;
}

public String getDescripcion() {
	return descripcion;
}

public int getUnidades() {
	return unidades;
}



public String toString() {
	return "-id: " + idProducto + ", nombre: " + nombre + ", precio: " + precio + ", descripcion: " + descripcion;
}


}
