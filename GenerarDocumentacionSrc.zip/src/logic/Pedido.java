package logic;

import java.util.ArrayList;
import java.util.List;



public class Pedido {
   private List<Paquete> listaPaquetes;
   private String IDPedido;
   
   public Pedido(String IDPedido ) {
	   this.listaPaquetes = new ArrayList<Paquete>();
	   this.IDPedido = IDPedido;
   }

public List<Paquete> getListaPaquetes() {
	return listaPaquetes;
}


public String getIDPedido() {
	return IDPedido;
}
   
   
}
