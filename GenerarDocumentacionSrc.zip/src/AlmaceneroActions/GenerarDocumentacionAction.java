package AlmaceneroActions;






import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import logic.Paquete;
import logic.Pedido;
import logic.Producto;

public class GenerarDocumentacionAction {
	
	private String URL = "jdbc:hsqldb:hsql://localhost";
	private String username = "sa";
	private String password = "";
	//En teoria no necesitaria una consulta puesto que ya tendria los datos de los productos dentro de cada paquete
	//La consulta necesaria seria para introducir los datos de los paquetes que se van a enviar
	
	public void execute(Pedido pedido) throws SQLException {
		
		Connection c = DriverManager.getConnection(URL);
		PreparedStatement pst = null;
		ResultSet rs = null;
		String albaran = "Albaran";
		albaran += "-------------------------";
		String idPedido = pedido.getIDPedido();
		int contadorPedido = 0;
		
		String sql = "update Pedido" + 
				"set albaran = ?" + 
				
				"where IDPedido = ?";
		
		
		for(Paquete p: pedido.getListaPaquetes()) {
			
			
			albaran += generarAlbaran(p.getListaProductos(),contadorPedido);
			albaran += "/n";
			contadorPedido++;
			
	
		}
		pst = c.prepareStatement(sql);
		pst.setString(1, albaran);
		pst.setString(2, idPedido);
		rs = pst.executeQuery();
	}
	
	
	
	private String generarAlbaran(List<Producto> paquete,int contadorPedido) {
		double precioTotal = 0;
		String albaran = "Pedido:" +  contadorPedido;
		albaran += "/n";
		albaran += "--------------------------/n";
		
		for(Producto p:paquete) {
			albaran += p.toString();
			albaran += "/n";
			precioTotal += p.getPrecio();
		}
		albaran += "--------------------------/n";
		albaran += "Precio Total: " + precioTotal;
		
		return albaran;
	}

}
